(function(){
    const EventType = Packages.mindustry.game.EventType;
    const WorldLoadEvent = EventType.WorldLoadEvent;
    const Tick = EventType.Tick;
    const ContentType = Packages.mindustry.ctype.ContentType;
    const Vars = Packages.mindustry.Vars;
    const Call = Packages.mindustry.gen.Call;

    const get = (type, name) => Vars.content.getByName(type, name);

    const CONFIG = {
        cobaltGoal: 100,
        cupritGoal: 50,
        freonGoal: 30,
        cuprofenGoal: 5,
        waveWarmupSeconds: 10
    };

    let resolved = false;
    let sectorStart, sectorWasteland;
    let cobalt, cuprit, carbon, bcoal, freon, cuprofen;
    let drill, north, cobaltWall, aspirator, diffuser;

    function resolveContent(){
        if(resolved) return;
        sectorStart = get(ContentType.sector, "bmod-b_start");
        sectorWasteland = get(ContentType.sector, "bmod-b_wasteland");

        cobalt = get(ContentType.item, "bmod-cobalt_item");
        cuprit = get(ContentType.item, "bmod-cuprit_item");
        carbon = get(ContentType.item, "bmod-carbon_item");
        bcoal = get(ContentType.item, "bmod-bcoal");
        cuprofen = get(ContentType.item, "bmod-cuprofen_item");
        freon = get(ContentType.liquid, "bmod-freon");

        drill = get(ContentType.block, "bmod-cobalt_drill");
        north = get(ContentType.block, "bmod-north");
        cobaltWall = get(ContentType.block, "bmod-cobalt-wall");
        aspirator = get(ContentType.block, "bmod-freon_aspirator");
        diffuser = get(ContentType.block, "bmod-freon-diffuser");

        resolved = true;
    }

    function teamCores(){
        try{
            if(Vars.player == null) return null;
            return Vars.player.team().data().cores;
        }catch(err){
            return null;
        }
    }

    function sumItem(item){
        const cores = teamCores();
        if(cores == null || item == null) return 0;
        let total = 0;
        for(let i = 0; i < cores.size; i++) total += cores.get(i).items.get(item);
        return total;
    }

    function sumLiquid(liquid){
        const cores = teamCores();
        if(cores == null || liquid == null) return 0;
        let total = 0;
        for(let i = 0; i < cores.size; i++) total += cores.get(i).liquids.get(liquid);
        return total;
    }

    function blockCount(block){
        try{
            if(Vars.player == null || block == null) return 0;
            return Vars.player.team().data().count(block);
        }catch(err){
            return 0;
        }
    }

    function mineItemStep(label, item, goal){
        let last = 0, total = 0;
        return {
            reset: function(){ last = sumItem(item); total = 0; },
            update: function(){
                const now = sumItem(item);
                if(now > last) total += (now - last);
                last = now;
            },
            done: function(){ return total >= goal; },
            progressText: function(){
                return label + ": " + Math.min(total, goal) + "/" + goal;
            }
        };
    }

    function mineLiquidStep(label, liquid, goal){
        let last = 0, total = 0;
        return {
            reset: function(){ last = sumLiquid(liquid); total = 0; },
            update: function(){
                const now = sumLiquid(liquid);
                if(now > last) total += (now - last);
                last = now;
            },
            done: function(){ return total >= goal; },
            progressText: function(){
                return label + ": " + Math.min(Math.round(total), goal) + "/" + goal;
            }
        };
    }

    function blockStep(label, block){
        return {
            reset: function(){},
            update: function(){},
            done: function(){
                return block != null && block.unlocked() && blockCount(block) > 0;
            },
            progressText: function(){
                if(block == null) return label + ": ?";
                const r = block.unlocked() ? "исследовано" : "не исследовано";
                const b = blockCount(block) > 0 ? "построено" : "не построено";
                return label + " — " + r + ", " + b;
            }
        };
    }

    function buildMissions(){
        return {
            start: {
                preset: sectorStart,
                title: "Ледяной причал",
                intro: [
                    "Обучение: обустройте плацдарм на Бореалисе.",
                    "1) Добудьте 100 кобальта.",
                    "2) Добудьте куприт.",
                    "3) Исследуйте и постройте Кобальтовый бур.",
                    "4) Исследуйте турель «Север» и постройте её.",
                    "5) Исследуйте Кобальтовую стену и постройте её.",
                    "Волны начнутся только после выполнения всех пунктов."
                ],
                steps: [
                    mineItemStep("Кобальт", cobalt, CONFIG.cobaltGoal),
                    mineItemStep("Куприт", cuprit, CONFIG.cupritGoal),
                    blockStep("Кобальтовый бур", drill),
                    blockStep("Турель «Север»", north),
                    blockStep("Кобальтовая стена", cobaltWall)
                ]
            },
            wasteland: {
                preset: sectorWasteland,
                title: "Ледяная пустошь",
                intro: [
                    "Обучение: энергетика Бореалиса держится на фреоне.",
                    "Фреон — подземный газ под давлением, выходящий из фреоновых жерл во льду.",
                    "Чтобы добыть фреон, постройте Аспиратор фреона прямо на жерле.",
                    "Из куприта и фреона Фреоновый диффузор синтезирует Купрофен — сверхпроводящий сплав.",
                    "1) Исследуйте и постройте Аспиратор фреона.",
                    "2) Добудьте фреон.",
                    "3) Исследуйте и постройте Фреоновый диффузор (синтезатор Купрофена).",
                    "4) Изготовьте Купрофен.",
                    "Волны начнутся только после выполнения всех пунктов."
                ],
                steps: [
                    blockStep("Аспиратор фреона", aspirator),
                    mineLiquidStep("Фреон", freon, CONFIG.freonGoal),
                    blockStep("Фреоновый диффузор", diffuser),
                    mineItemStep("Купрофен", cuprofen, CONFIG.cuprofenGoal)
                ]
            }
        };
    }

    let active = null;
    let unlocked = false;
    let hudTable = null;
    let hudLabel = null;

    function log(text){
        try{ Call.sendMessage(text); }catch(err){}
        print(text);
    }

    function removeHud(){
        try{
            if(hudTable != null){ hudTable.remove(); }
        }catch(err){}
        hudTable = null;
        hudLabel = null;
    }

    function buildHud(mission){
        try{
            const Table = Packages.arc.scene.ui.layout.Table;

            removeHud();
            hudTable = new Table();
            hudTable.setFillParent(true);
            hudTable.top().left().marginTop(90).marginLeft(10);
            Vars.ui.hudGroup.addChild(hudTable);

            hudLabel = hudTable.add("").left().get();
            hudLabel.setWrap(false);
        }catch(err){
            print("Borealis tutorial: HUD panel unavailable (" + err + "), falling back to chat log only.");
            hudTable = null;
            hudLabel = null;
        }
    }

    function refreshHud(mission){
        if(hudLabel == null) return;
        try{
            let text = "[accent]" + mission.title + "[]\n";
            for(let i = 0; i < mission.steps.length; i++){
                const s = mission.steps[i];
                const mark = s.done() ? "[green]v[] " : "[gray]o[] ";
                text += mark + s.progressText() + "\n";
            }
            hudLabel.setText(text);
        }catch(err){
        }
    }

    function allDone(mission){
        for(let i = 0; i < mission.steps.length; i++){
            if(!mission.steps[i].done()) return false;
        }
        return true;
    }

    function startMission(mission){
        active = mission;
        unlocked = false;

        for(let i = 0; i < mission.steps.length; i++) mission.steps[i].reset();

        try{ Vars.state.rules.waves = false; }catch(err){}

        for(let i = 0; i < mission.intro.length; i++) log(mission.intro[i]);
        buildHud(mission);
        refreshHud(mission);
    }

    function stopTracking(){
        active = null;
        removeHud();
    }

    function unlockWaves(mission){
        unlocked = true;
        try{
            Vars.state.rules.waves = true;
            Vars.state.wavetime = CONFIG.waveWarmupSeconds * 60;
        }catch(err){
            print("Borealis tutorial: failed to unlock waves (" + err + ")");
        }
        log("Все объекты обучения на секторе «" + mission.title + "» выполнены. Волны начнутся через " + CONFIG.waveWarmupSeconds + " секунд!");
    }

    Events.on(WorldLoadEvent, e => {
        try{
            resolveContent();
            const missions = buildMissions();

            const rulesSector = (Vars.state.rules != null) ? Vars.state.rules.sector : null;
            const preset = (rulesSector != null) ? rulesSector.preset : null;

            let mission = null;
            if(preset != null){
                if(preset == missions.start.preset) mission = missions.start;
                else if(preset == missions.wasteland.preset) mission = missions.wasteland;
            }

            if(mission == null){
                stopTracking();
                return;
            }

            if(Vars.state.wave <= 1){
                startMission(mission);
            } else {
                active = null;
                unlocked = true;
                removeHud();
            }
        }catch(err){
            print("Borealis tutorial: WorldLoadEvent handler failed (" + err + ")");
        }
    });

    Events.on(Tick, e => {
        if(active == null || unlocked) return;
        try{
            for(let i = 0; i < active.steps.length; i++) active.steps[i].update();
            refreshHud(active);
            if(allDone(active)){
                unlockWaves(active);
                removeHud();
            }
        }catch(err){
            print("Borealis tutorial: Tick handler failed (" + err + ")");
            active = null;
        }
    });
})();
