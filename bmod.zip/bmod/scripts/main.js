const ContentInitEvent = Packages.mindustry.game.EventType.ContentInitEvent;
const ClientLoadEvent = Packages.mindustry.game.EventType.ClientLoadEvent;
const ContentType = Packages.mindustry.ctype.ContentType;
const TechTree = Packages.mindustry.content.TechTree;
const Vars = Packages.mindustry.Vars;
const Schematic = Packages.mindustry.game.Schematic;
const Stile = Packages.mindustry.game.Schematic.Stile;
const Seq = Packages.arc.struct.Seq;
const StringMap = Packages.arc.struct.StringMap;

const Team = Packages.mindustry.game.Team;

const severTeam = Team.get(7);
severTeam.name = "sever";

function applySeverLook(){
    const Color = Packages.arc.graphics.Color;
    const light = Color.valueOf("6fa9a8");
    severTeam.setPalette(
        light,
        Color.valueOf("405a68"),
        Color.valueOf("26383f")
    );
    try{ severTeam.color.set(light); }catch(err){ print("Sever: cannot set team colour (" + err + ")"); }
}
applySeverLook();

const SEVER_PATCH_BASE_TEAMS = true;

function registerSeverBaseTeam(){
    if(!SEVER_PATCH_BASE_TEAMS) return false;
    try{
        const cur = Team.baseTeams;
        if(cur == null || cur.length == undefined) return false;
        for(let i = 0; i < cur.length; i++){
            if(cur[i] == severTeam) return true;
        }
        const teamClass = severTeam.getClass();
        const JArray = java.lang.reflect.Array;
        const next = JArray.newInstance(teamClass, cur.length + 1);
        for(let i = 0; i < cur.length; i++) JArray.set(next, i, cur[i]);
        JArray.set(next, cur.length, severTeam);

        const field = teamClass.getDeclaredField("baseTeams");
        field.setAccessible(true);
        try{
            const mods = field.getClass().getDeclaredField("modifiers");
            mods.setAccessible(true);
            mods.setInt(field, field.getModifiers() & ~java.lang.reflect.Modifier.FINAL);
        }catch(err){}
        field.set(null, next);
        print("Sever: added to Team.baseTeams (" + Team.baseTeams.length + " teams).");
        return true;
    }catch(err){
        print("Sever: cannot extend Team.baseTeams (" + err + ")");
        return false;
    }
}
const severInBaseTeams = registerSeverBaseTeam();

try{
    const gradRocket = new Packages.mindustry.type.unit.MissileUnitType("grad-rocket");
    try{
        gradRocket.constructor = prov(() => Packages.mindustry.gen.TimedKillUnit.create());
    }catch(err){ print("Grad rocket: constructor not set (" + err + ")"); }
}catch(err){
    print("Grad rocket: MissileUnitType unavailable, using the hjson fallback (" + err + ")");
}

Events.on(ContentInitEvent, e => {
    const get = (type, name) => Vars.content.getByName(type, name);

    const borealis = get(ContentType.planet, "bmod-borealis");
    const outpost = get(ContentType.block, "bmod-outpost");
    const sector = get(ContentType.sector, "bmod-b_start");

    const bcoal = get(ContentType.item, "bmod-bcoal");
    const cobalt = get(ContentType.item, "bmod-cobalt_item");
    const cuprit = get(ContentType.item, "bmod-cuprit_item");
    const carbon = get(ContentType.item, "bmod-carbon_item");

    const heater = get(ContentType.block, "bmod-borealis-heater");
    const crusher = get(ContentType.block, "bmod-cliff_crusher");
    const roller = get(ContentType.block, "bmod-coal_roller");
    const drill = get(ContentType.block, "bmod-cobalt_drill");
    const conveyor = get(ContentType.block, "bmod-c_conveyor");
    const router = get(ContentType.block, "bmod-brouter");
    const crossroad = get(ContentType.block, "bmod-bcrossroad");

    const cobaltWall = get(ContentType.block, "bmod-cobalt-wall");
    const cobaltWallLarge = get(ContentType.block, "bmod-cobalt-wall-large");
    const north = get(ContentType.block, "bmod-north");
    const hearth = get(ContentType.block, "bmod-hearth");
    const blizzard = get(ContentType.block, "bmod-blizzard");

    const frozenLand = get(ContentType.sector, "bmod-frozen-land");
    const aspirator = get(ContentType.block, "bmod-freon_aspirator");
    const conduit = get(ContentType.block, "bmod-carbon-conduit");
    const carbonJunction = get(ContentType.block, "bmod-carbon-junction");
    const carbonRouter = get(ContentType.block, "bmod-carbon-router");
    const diffuser = get(ContentType.block, "bmod-freon-diffuser");
    const cuprofen = get(ContentType.item, "bmod-cuprofen_item");

    if(borealis == null || outpost == null){
        print("Borealis tech tree: missing Borealis or Outpost.");
        return;
    }

    const Objectives = Packages.mindustry.game.Objectives;

    const researchOf = (a, b, c, d) => {
        const seq = new Seq();
        if(a != null) seq.add(new Objectives.Research(a));
        if(b != null) seq.add(new Objectives.Research(b));
        if(c != null) seq.add(new Objectives.Research(c));
        if(d != null) seq.add(new Objectives.Research(d));
        return seq;
    };

    const landedOn = (preset) => {
        if(preset == null) return null;
        try{
            return new JavaAdapter(Objectives.Objective, {
                complete: function(){
                    try{ return preset.sector != null && preset.sector.hasBase(); }catch(err){ return false; }
                },
                display: function(){
                    return "Высадитесь на секторе «" + preset.localizedName + "»";
                }
            });
        }catch(err){
            print("Borealis tech tree: custom landing objective failed (" + err + "), trying Objectives.Launch.");
        }
        try{ return new Objectives.Launch(preset); }catch(err){
            print("Borealis tech tree: landing objective unavailable (" + err + ").");
        }
        return null;
    };

    [outpost, sector, bcoal, cobalt, cuprit, carbon, heater, crusher, roller,
     drill, conveyor, router, crossroad, cobaltWall, cobaltWallLarge, north,
     hearth, blizzard, frozenLand, aspirator, conduit, carbonJunction,
     carbonRouter, diffuser, cuprofen].forEach(c => {
        if(c != null && c.techNodes != null){
            c.techNodes.each(n => n.remove());
            c.techNodes.clear();
            c.techNode = null;
        }
    });

    const root = TechTree.nodeRoot("borealis", outpost, false, () => {
        if(sector != null) TechTree.node(sector, () => {
            if(frozenLand != null){
                const toFrozen = new Seq();
                toFrozen.add(new Objectives.SectorComplete(sector));
                TechTree.node(frozenLand, toFrozen, () => {
                    if(aspirator != null){
                        const aspObj = researchOf(carbon);
                        const landed = landedOn(frozenLand);
                        if(landed != null) aspObj.add(landed);
                        TechTree.node(aspirator, aspObj, () => {
                            if(conduit != null){
                                TechTree.node(conduit, researchOf(), () => {
                                    if(carbonJunction != null) TechTree.node(carbonJunction, researchOf(), () => {});
                                    if(carbonRouter != null) TechTree.node(carbonRouter, researchOf(), () => {});
                                    if(diffuser != null){
                                        TechTree.node(diffuser, researchOf(cuprit), () => {
                                            if(cuprofen != null) TechTree.nodeProduce(cuprofen, () => {});
                                        });
                                    }
                                });
                            }
                        });
                    }
                });
            }
        });

        if(cobalt != null){
            TechTree.nodeProduce(cobalt, () => {
                if(cuprit != null){
                    TechTree.nodeProduce(cuprit, () => {
                        if(bcoal != null){
                            TechTree.nodeProduce(bcoal, () => {
                                if(carbon != null) TechTree.nodeProduce(carbon, () => {});
                            });
                        }
                    });
                }
            });
        }

        if(drill != null){
            TechTree.node(drill, researchOf(cobalt), () => {});
        }

        if(conveyor != null){
            TechTree.node(conveyor, researchOf(cobalt), () => {});
        }

        if(router != null){
            TechTree.node(router, researchOf(cobalt, cuprit), () => {});
        }

        if(crossroad != null){
            TechTree.node(crossroad, researchOf(cobalt, cuprit), () => {});
        }

        if(crusher != null){
            TechTree.node(crusher, researchOf(cobalt, cuprit), () => {});
        }

        if(heater != null){
            TechTree.node(heater, researchOf(cobalt, cuprit), () => {});
        }

        if(roller != null){
            TechTree.node(roller, researchOf(cobalt, cuprit), () => {});
        }

        if(cobaltWall != null){
            TechTree.node(cobaltWall, researchOf(cobalt), () => {
                if(cobaltWallLarge != null){
                    TechTree.node(cobaltWallLarge, researchOf(cobalt), () => {});
                }
            });
        }

        if(north != null){
            TechTree.node(north, researchOf(cobalt), () => {
                if(hearth != null){
                    TechTree.node(hearth, researchOf(cobalt, cuprit), () => {
                        if(blizzard != null){
                            TechTree.node(blizzard, researchOf(cobalt, cuprit, carbon), () => {});
                        }
                    });
                }
            });
        }
    });

    root.each(n => { n.planet = borealis; });
    root.addPlanet(borealis);
    borealis.techTree = root;

    print("Borealis tech tree loaded: resources are a separate branch; resource research directly gates dependent content.");
});

Events.on(ClientLoadEvent, e => {
    const borealis = Vars.content.getByName(ContentType.planet, "bmod-borealis");
    const outpost = Vars.content.getByName(ContentType.block, "bmod-outpost");
    if(borealis == null || outpost == null || Vars.schematics == null) return;

    try{
        const launchSchem = new Schematic(
            Seq.with(new Stile(outpost, 0, 0, null, 0)),
            new StringMap(),
            outpost.size,
            outpost.size
        );
        launchSchem.tags.put("name", "Бореалис: Форпост");
        launchSchem.tags.put("description", "Стандартная высадка на Бореалис с ядром «Форпост».");

        const loadouts = Vars.schematics.getLoadouts(outpost);
        let exists = false;
        for(let i = 0; i < loadouts.size; i++){
            if(loadouts.get(i).name() == "Бореалис: Форпост"){
                exists = true;
                break;
            }
        }
        if(!exists) loadouts.add(launchSchem);

        Vars.universe.updateLoadout(outpost, launchSchem);
        if(borealis.generator != null) borealis.generator.defaultLoadout = launchSchem;
        print("Borealis launch loadout: custom Outpost schematic installed.");
    }catch(err){
        print("Borealis launch loadout setup failed: " + err);
    }
    print("Borealis tech tree loaded: no Frigit/Crusher cycle; turret and all mod researchable content added.");
});

const WallCrafter = Packages.mindustry.world.blocks.production.WallCrafter;
const Draw = Packages.arc.graphics.g2d.Draw;
const Layer = Packages.mindustry.graphics.Layer;

Events.on(ContentInitEvent, cons(e => {
    const crusher = Vars.content.getByName(ContentType.block, "bmod-cliff_crusher");
    if(crusher == null) return;

    crusher.buildType = prov(() => new JavaAdapter(WallCrafter.WallCrafterBuild, {
        draw: function(){
            const b = this;
            const block = b.block;
            const size = block.size;

            const cornerX = b.tile.x - Math.floor((size - 1) / 2);
            const cornerY = b.tile.y - Math.floor((size - 1) / 2);
            const s = size;

            const sideOffset = 0;

            let positions = [];
            for(let i = 0; i < size; i++){
                let rx = 0, ry = 0;
                switch(b.rotation){
                    case 0:
                        rx = cornerX + s;
                        ry = cornerY + i;
                        break;
                    case 1:
                        rx = cornerX + i;
                        ry = cornerY + s;
                        break;
                    case 2:
                        rx = cornerX - 1;
                        ry = cornerY + i;
                        break;
                    case 3:
                        rx = cornerX + i;
                        ry = cornerY - 1;
                        break;
                }
                positions.push({x: rx * Vars.tilesize, y: ry * Vars.tilesize});
            }

            let dx = 0, dy = 0;
            switch(b.rotation){
                case 0: dx = 0.5; dy = 0; break;
                case 1: dx = 0; dy = 0.5; break;
                case 2: dx = -0.5; dy = 0; break;
                case 3: dx = 0; dy = -0.5; break;
            }
            for(let i = 0; i < positions.length; i++){
                let p = positions[i];
                let sign = i >= size / 2 && size % 2 == 0 ? -1 : 1;
                let vx = (p.x / Vars.tilesize - dx) * Vars.tilesize;
                let vy = (p.y / Vars.tilesize - dy) * Vars.tilesize;

                Draw.z(Layer.block - 0.002);
                Draw.rect(
                    Core.atlas.find("bmod-cliff_crusher-rotator2-bottom"),
                    vx, vy,
                    b.totalTime * block.rotateSpeed * sign
                );

                Draw.z(Layer.block - 0.001);
                Draw.rect(
                    Core.atlas.find("bmod-cliff_crusher-rotator2"),
                    vx, vy,
                    b.totalTime * block.rotateSpeed * sign
                );
            }

            Draw.z(Layer.block);
            Draw.rect(Core.atlas.find("bmod-cliff_crusher"), b.x, b.y);

            Draw.z(Layer.blockOver);
            Draw.rect(
                Core.atlas.find("bmod-cliff_crusher-rotator1"),
                b.x, b.y,
                b.totalTime * block.rotateSpeed
            );

            Draw.z(Layer.blockOver + 0.002);
            Draw.rect(
                Core.atlas.find("bmod-cliff_crusher-rotator1-top"),
                b.x, b.y
            );
        }
    }, crusher));

    print("Cliff Crusher: native WallCrafter mining + custom 5-layer draw loaded.");
}));

const HeatConsumer = Packages.mindustry.world.blocks.heat.HeatConsumer;
const UnitFactory = Packages.mindustry.world.blocks.units.UnitFactory;
const Reconstructor = Packages.mindustry.world.blocks.units.Reconstructor;
const Mathf = Packages.arc.math.Mathf;
const JFloat = java.lang.Float.TYPE;
const JArray = java.lang.reflect.Array;

const heatBridgeTargets = [
    { name: "bmod-primary_assembler",          superBuild: () => UnitFactory.UnitFactoryBuild,     heatReq: 1.2 },
    { name: "bmod-heavy_assembler",             superBuild: () => UnitFactory.UnitFactoryBuild,     heatReq: 2.5 },
    { name: "bmod-main_reconstructor_grad",     superBuild: () => Reconstructor.ReconstructorBuild, heatReq: 2.0 },
    { name: "bmod-main_reconstructor_threat",   superBuild: () => Reconstructor.ReconstructorBuild, heatReq: 2.0 },
    { name: "bmod-main_reconstructor_tracer",   superBuild: () => Reconstructor.ReconstructorBuild, heatReq: 2.2 },
];

Events.on(ContentInitEvent, cons(e => {
    let attached = 0;

    heatBridgeTargets.forEach(t => {
        const block = Vars.content.getByName(ContentType.block, t.name);
        if(block == null){
            print("Heat bridge: block not found: " + t.name);
            return;
        }

        const heatReq = t.heatReq;
        const SuperBuild = t.superBuild();

        block.buildType = prov(() => new JavaAdapter(SuperBuild, HeatConsumer, {
            sideHeat: function(){
                if(this._sideHeatArr == null){
                    this._sideHeatArr = JArray.newInstance(JFloat, this.block.size * 4);
                }
                return this._sideHeatArr;
            },
            heatRequirement: function(){
                return heatReq;
            },
            updateTile: function(){
                this.calculateHeat(this.sideHeat());

                let heat = 0;
                const arr = this.sideHeat();
                for(let i = 0; i < arr.length; i++) heat += arr[i];

                const heatEff = Mathf.clamp(heat / heatReq, 0, 1);
                this.efficiency *= heatEff;

                this.super$updateTile();
            }
        }, block));

        attached++;
    });

    print("Heat bridge: attached HeatConsumer to " + attached + " unit factories.");
}));

function addSeverToEditor(){
    const ImageButton = Packages.arc.scene.ui.ImageButton;
    const Group = Packages.arc.scene.Group;
    const Table = Packages.arc.scene.ui.layout.Table;
    const Tex = Packages.mindustry.gen.Tex;
    const Styles = Packages.mindustry.ui.Styles;

    if(Vars.ui == null || Vars.ui.editor == null || Vars.editor == null) return "editor not ready";

    const baseColors = [Team.sharded.color, Team.crux.color, Team.malis.color, Team.green.color, Team.blue.color, Team.derelict.color];
    let sample = null, total = 0, hasSever = false;
    const walk = el => {
        if(el == null) return;
        if(el instanceof ImageButton){
            total++;
            const st = el.getStyle();
            const c = st == null ? null : st.imageUpColor;
            if(c != null){
                if(c.equals(severTeam.color)) hasSever = true;
                else if(sample == null){
                    for(let i = 0; i < baseColors.length; i++){
                        if(c.equals(baseColors[i])){ sample = el; break; }
                    }
                }
            }
        }
        if(el instanceof Group){
            const ch = el.getChildren();
            for(let i = 0; i < ch.size; i++) walk(ch.get(i));
        }
    };
    walk(Vars.ui.editor);

    if(hasSever) return "ok";
    if(sample == null) return "team buttons not found (image buttons: " + total + ")";

    const parent = sample.parent;
    if(parent == null) return "no parent";
    if(parent.find("bmod-sever-team-button") != null) return "ok";

    const btn = new ImageButton(Tex.whiteui, Styles.clearTogglei);
    btn.name = "bmod-sever-team-button";
    btn.margin(4);
    btn.getImageCell().grow();
    btn.getStyle().imageUpColor = severTeam.color;
    btn.clicked(run(() => { Vars.editor.drawTeam = severTeam; }));
    btn.update(run(() => { btn.setChecked(Vars.editor.drawTeam == severTeam); }));

    const w = sample.getWidth() > 0 ? sample.getWidth() : 40;
    const h = sample.getHeight() > 0 ? sample.getHeight() : 40;
    if(parent instanceof Table){
        parent.add(btn).size(w, h);
    }else{
        btn.setSize(w, h);
        parent.addChild(btn);
    }
    try{
        const grp = sample.getButtonGroup();
        if(grp != null) grp.add(btn);
    }catch(err){}

    print("Sever: team button added to the map editor.");
    return "ok";
}

let severFallbackDone = false;
let severFallbackTimer = 0;

function pollSeverEditor(){
    if(severFallbackDone) return;
    if(++severFallbackTimer % 30 != 0) return;
    try{
        if(Vars.ui == null || Vars.ui.editor == null || !Vars.ui.editor.isShown()) return;
        const res = addSeverToEditor();
        if(res == "ok") severFallbackDone = true;
        else print("Sever: editor fallback - " + res);
    }catch(err){
        severFallbackDone = true;
        print("Sever: editor fallback failed (" + err + ")");
    }
}

Events.on(ClientLoadEvent, e => {
    try{
        applySeverLook();
        if(!severInBaseTeams){
            Events.run(Packages.mindustry.game.EventType.Trigger.update, run(() => pollSeverEditor()));
        }
    }catch(err){
        print("Sever: could not start editor fallback (" + err + ")");
    }
});

Events.on(ContentInitEvent, cons(e => {
    try{
        const SoundsClass = java.lang.Class.forName("mindustry.gen.Sounds");
        const fields = SoundsClass.getFields();
        const names = [];
        for(let i = 0; i < fields.length; i++){
            if(java.lang.reflect.Modifier.isStatic(fields[i].getModifiers())) names.push(String(fields[i].getName()));
        }
        print("Borealis sounds available: " + names.join(", "));

        const pick = (patterns) => {
            for(let p = 0; p < patterns.length; p++){
                const re = new RegExp(patterns[p], "i");
                for(let i = 0; i < names.length; i++){
                    if(re.test(names[i])) return SoundsClass.getField(names[i]).get(null);
                }
            }
            return null;
        };
        const flame = pick(["^flame$", "shootflame", "flame", "fire"]);
        const spray = pick(["^spray$", "shootspray", "spray", "liquid", "water"]);
        const missile = pick(["^missile$", "shootmissile", "missilelaunch", "missile", "rocket"]);
        const big = pick(["^shootbig$", "shootbig", "shoot.*big", "big"]);

        const turretSound = (name, snd) => {
            const b = Vars.content.getByName(ContentType.block, name);
            if(b != null && snd != null) b.shootSound = snd;
        };
        turretSound("bmod-hearth", flame);
        turretSound("bmod-blizzard", spray);
        turretSound("bmod-north", big);

        const unitByName = (n) => Vars.content.getByName(ContentType.unit, n);
        const eachWeapon = (n, fn) => {
            const u = unitByName(n);
            if(u == null) return;
            for(let i = 0; i < u.weapons.size; i++) fn(u.weapons.get(i), i);
        };
        const setShot = (n, snd, match) => {
            if(snd == null) return;
            eachWeapon(n, (w) => { if(match == null || String(w.name).indexOf(match) >= 0) w.shootSound = snd; });
        };
        const setHit = (n, snd, vol) => {
            if(snd == null) return;
            eachWeapon(n, (w) => {
                if(w.bullet == null) return;
                w.bullet.hitSound = snd;
                w.bullet.hitSoundVolume = vol;
            });
        };

        const light   = pick(["^shoot$", "^shootalt$", "^pew$"]);
        const cannon  = pick(["^bang$", "^shootsnap$", "^shootalt$", "^shoot$"]);
        const artil   = pick(["artillery", "cannon", "^shootsnap$", "^bang$", "^shootbig$", "^shootaltlong$", "^shootalt$", "^shoot$"]);
        const heavy   = pick(["^shootbig$", "artillery", "cannon", "^bang$", "^shootsnap$", "^shootaltlong$", "^explosion$", "^shootalt$", "^shoot$"]);
        const rocket  = missile != null ? missile : pick(["^shootalt$", "^shoot$", "^pew$"]);
        const boom    = pick(["^explosion$", "^dullexplosion", "largeexplosion", "^bang$"]);

        const nm = (s) => (s == null ? "none" : String(s));
        print("Borealis unit sounds: light=" + nm(light) + " cannon=" + nm(cannon) + " artillery=" + nm(artil) +
              " heavy=" + nm(heavy) + " rocket=" + nm(rocket) + " boom=" + nm(boom));

        setShot("bmod-klin", light);
        setShot("bmod-threat", light);
        setShot("bmod-caliber", cannon);
        setShot("bmod-tracer", artil);
        setShot("bmod-lafet", heavy);
        setShot("bmod-grad", rocket);
        setShot("bmod-squall", rocket, "launcher");
        setShot("bmod-squall", light, "gun");

        setHit("bmod-tracer", boom, 0.35);
        setHit("bmod-lafet", boom, 0.6);
        setHit("bmod-grad-rocket", boom, 0.7);
    }catch(err){
        print("Borealis sounds: could not assign sounds (" + err + ")");
    }
}));

Events.on(ContentInitEvent, cons(e => {
    try{
        const bt = [];
        for(let i = 0; i < Team.baseTeams.length; i++) bt.push(i + ":" + Team.baseTeams[i].name);
        print("Sever: Team.get(7).name=" + severTeam.name + ", id=" + severTeam.id + ", baseTeams=[" + bt.join(", ") + "]");
    }catch(err){ print("Sever: diagnostics failed (" + err + ")"); }
    try{
        const entries = Vars.content.getBy(ContentType.team);
        const list = [];
        entries.each(cons(t => list.push(String(t.name))));
        print("Sever: team content entries: [" + list.join(", ") + "]");
    }catch(err){ print("Sever: no team content type (" + err + ")"); }
}));
